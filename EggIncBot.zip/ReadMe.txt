Requirements
-1080p monitor
-BlueStacks in Landscape (Tablet Mode) default 1600x900 in fullscreen windowed
-Windows night light disabled